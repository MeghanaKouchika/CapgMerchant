package com.capgemini.merchantstore.exceptions;

public class CategoryNotFoundException {

}
